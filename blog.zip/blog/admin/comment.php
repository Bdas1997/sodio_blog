<?php
session_start();

 include 'connection.php';
error_reporting(0);
if (!isset($_SESSION['username'])){
    header("location:index.php");
}

include "include/header.php";
include "include/nav.php";

// $id=$_GET['id'];
$delid = $_GET['delid'];



if ($delid != ""){

    $upsql = "delete from blog_comments where id={$delid}";            

    mysqli_query($conn,$upsql);

    $msg = "Comment Deleted Successfully.";

    setcookie("msg", $msg, time() + 3);

    header("Location: comment.php");

}

?>


  <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                     
                    <div class="col-sm-12 p-md-0">
                        <div class="welcome-text">
                            <h4>Comment Review</h4>
                            
                        </div>
                                
                                <div class="table-responsive mt-2">
                                <table id="zero_config" class="table table-striped table-bordered no-wrap">
    <thead>
        <tr>
            <th style="color:#000;">Name</th>
            <th style="color:#000;">Message</th>
            <th style="color:#000;">Email</th>
            <th style="color:#000;">Blog Title</th>
            <th style="color:#000;">Status</th>
            <th class="text-center" style="width:240px;color: #000;">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sqlfetch = "SELECT * FROM blog_comments";
        $sqlfetch = mysqli_query($conn, $sqlfetch);

        while ($row = mysqli_fetch_array($sqlfetch)) {
            $sqlfetch2 = "SELECT * FROM blogs WHERE id='{$row['blog_id']}'";
            $sqlfetch2 = mysqli_query($conn, $sqlfetch2);
            $row1 = mysqli_fetch_array($sqlfetch2);
        ?>
            <tr>
                <td style="color:#000;"><?php echo $row['name']; ?></td>
                <td style="color:#000;"><?php echo $row['comment']; ?></td>
                <td style="color:#000;"><?php echo $row['email']; ?></td>
                <td style="color:#000;"><?php echo $row1['blog_title']; ?></td>
                <td style="color:#000;">
                    <button class="status-toggle btn btn-sm <?php echo ($row['status'] == 2) ? 'btn-danger' : 'btn-success'; ?>" 
                            data-id="<?php echo $row['id']; ?>" 
                            data-status="<?php echo $row['status']; ?>">
                        <?php echo ($row['status'] == 2) ? 'Inactive' : 'Active'; ?>
                    </button>
                </td>
                <td class="text-center" style="color:#000;">
                    <a href="?delid=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure to delete?')"><i class="fas fa-trash-alt"></i></a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
            
           
           
        </div>
        
    </div>






<?php include "include/footer.php";?>

<script>
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".status-toggle").forEach(function (button) {
        button.addEventListener("click", function () {
            const commentId = this.getAttribute("data-id");
            const currentStatus = this.getAttribute("data-status");
            const newStatus = currentStatus == 2 ? 1 : 2; // Toggle status

            fetch("update_comment_status.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id: commentId, status: newStatus })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        this.textContent = newStatus == 2 ? "Inactive" : "Active";
                        this.classList.toggle("btn-success", newStatus == 1);
                        this.classList.toggle("btn-danger", newStatus == 2);
                        this.setAttribute("data-status", newStatus);
                    } else {
                        alert("Failed to update status.");
                    }
                })
                .catch(error => console.error("Error:", error));
        });
    });
});

</script>    