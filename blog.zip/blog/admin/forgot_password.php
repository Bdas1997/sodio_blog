<?php
include('connection.php');
require '../mailclass/Exception.php';
require '../mailclass/PHPMailer.php';
require '../mailclass/SMTP.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Extract POST data
$email = $_POST['email'] ?? '';

// Validate email
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    // Generate a random 4-digit password
    $password = rand(0000,9999);
    $password_hash = md5($password);

    // Prepare and execute SQL query
    $sql = "UPDATE `registration` SET password = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $password_hash, $email);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        // Prepare the email message
        $message = "
        <div align='center'>
        <table border='0' width='95%' cellpadding='2' style='font-family: Verdana; font-size: 8pt; color: #000000'>
            <tr>
                <td width='25%' align='left' valign='top'><b>Email</b></td>
                <td width='75%' align='left' valign='top'>$email</td>
            </tr>
            <tr>
                <td width='25%' align='left' valign='top'><b>New Password</b></td>
                <td width='75%' align='left' valign='top'>$password</td>
            </tr>
        </table>
        </div>";

$mail = new PHPMailer\PHPMailer\PHPMailer();

$subject    = "New Password";      
$Sender     =  $email;             
$Recipiant  = "bikashdasok@gmail.com";//ADMINEMAIL;
$fname    = "BIKASH";
 
$mail->setFrom($Sender, $fname);
$mail->addAddress($Recipiant, 'BIKASH');
$mail->Subject  = $subject; 

// $mail->AddAttachment($_FILES['attach']['tmp_name'], $_FILES['attach']['name']);

$mail->isHTML(true);
$mail->Body  = $message;
$mail->send(); 
    } else {
        echo "Failed to update password. Please check the email address.";
    }

    $stmt->close();
} else {
    echo "Invalid email address.";
}

$conn->close();
?>
