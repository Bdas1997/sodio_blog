 <div class="quixnav">
            <div class="quixnav-scroll">
                <ul class="metismenu" id="menu">
                    <li class="nav-label first">Main Menu</li>
                    
                    <li><a class="" href="dashboard.php" aria-expanded="false"><i
                                class="fas fa-tachometer-alt"></i><span class="nav-text">Dashboard</span></a>
                        
                    </li>

                    <!-- <li class="nav-label">Employee Management</li> -->
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                                <i class="fas fa-box"></i><span class="nav-text">Blog Management</span></a>
                        <ul aria-expanded="false">
                            
                            <li><a href="blog_add.php">Blog Add</a></li>
                                    <li><a href="blog_view.php">Blog List</a></li>
                                    <li><a href="comment.php">Blog Comment</a></li>
                                    
                            </li>
                        </ul>
                            
                      
                             </div>
                        </div>