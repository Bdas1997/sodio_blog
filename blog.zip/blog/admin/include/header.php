<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Admin</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="#">
    <link href="./vendor/pg-calendar/css/pignose.calendar.min.css" rel="stylesheet">
    <link href="./vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="./vendor/chartist/css/chartist.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous">
    <link href="./css/style.css" rel="stylesheet">

</head>

<body style="background: linear-gradient(to bottom,#343957 0%, #343957 100%);">

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="dashboard.php" class="brand-logo">
               
                <img class="brand-title" src="../img/logo-2.png" alt="" style="height:50px;width: 100px;" >
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="search_bar dropdown">
                                <span class="search_icon p-3 c-pointer" data-toggle="dropdown">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                                <div class="dropdown-menu p-0 m-0">
                                    <form>
                                        <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                                    </form>
                                </div>
                            </div>
                        </div>

                        
                                    
                                </div>
                            </li>
                            <li class="nav-item dropdown header-profile">
                                 <b style="color: #000;">Settings</b>
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <i class="fas fa-user" style="color:#000"></i>
                                    
                                </a>

                                <div class="dropdown-menu dropdown-menu-right">
                                       <a href="cpass.php" class="dropdown-item">
                                        <i class="fas fa-key"></i>
                                        <span class="ml-2">Change Password </span>
                                    </a>
                                    
                 
                                    <a href="logout.php" class="dropdown-item">
                                        <i class="fas fa-running"></i>
                                        <span class="ml-2">Logout </span>
                                    </a>
                                    <a href="page-lock-screen.php" class="dropdown-item">
                                        <i class="fas fa-lock"></i>
                                        <span class="ml-2">Lock Screen</span>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>