<?php
session_start();

include 'connection.php'; // Include your database connection file

// Get JSON input
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['id'], $data['status'])) {
    $id = intval($data['id']); // Ensure `id` is an integer
    $status = intval($data['status']); // Ensure `status` is an integer

    // Construct the SQL query securely
    $sql = "UPDATE `blog_comments` SET `status` = $status WHERE `id` = $id";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to update status."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request."]);
}

// Close the connection
mysqli_close($conn);
?>
