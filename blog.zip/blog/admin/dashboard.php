<?php
session_start();
include 'connection.php';
if (!isset($_SESSION['username'])):
    header("location:index.php");
endif; 
include "include/header.php";
include "include/nav.php";
?>
        
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-12 p-md-0">
                        <div class="welcome-text">
                            <h4>Hi, Welcome</h4>
                           
                        </div>
                    </div>
                    
                </div>

                <div class="row">
                    <div class="col-lg-4 col-sm-12">
                        <div class="card">
                            <div class="stat-widget-one card-body">
                                <div class="stat-icon d-inline-block">
                                    <i class="fas fa-layer-group text-primary border-primary"></i>
                                </div>
                                <?php 
                                $sql="SELECT * FROM blogs WHERE status = 1";
                                $result=mysqli_query($conn,$sql);
                                $row=mysqli_num_rows($result);
                                
                                ?>
                                <div class="stat-content d-inline-block">
                                    <div class="stat-text">Blog</div>
                                    <div class="stat-digit"><?php echo $row;?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                     
               
                </div>
                  <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body">
                                <div class=""><span id='date-time' style="color:#000;"></span></div>
                            </div>
                        </div>
                        <!-- /# card -->
                    </div>
                    
                </div>
                
                    
                    

                    <div class="col-xl-12 col-xxl-6 col-lg-6 col-md-12">
                        <div class="row">
                         
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="year-calendar"></div>
                            </div>
                        </div>
                        <!-- /# card -->
                    </div>
                    
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
<script>
var dt = new Date();
document.getElementById('date-time').innerHTML=dt;
</script>

    <?php include "include/footer.php";?>