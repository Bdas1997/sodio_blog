<?php 
error_reporting(0);
session_start();
include 'connection.php';
if (!isset($_SESSION['username'])){
    header("location:index.php");
}

include "include/header.php";
include "include/nav.php";
$delid = $_GET['delid'];



if ($delid != ""){

    $upsql = "delete from blog where id={$delid}";            

    db_query($upsql);

    $msg = "Blog Deleted Successfully.";

    setcookie("msg", $msg, time() + 3);

    header("Location: blog_view.php");

}

?>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Blog List</h4>
                            
                        </div>
                    </div>
                    
                </div>
                <!-- row -->


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <!-- <div class="card-header">
                                <h4 class="card-title">Employee List</h4>
                            </div> -->
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th class="text-center" style="width:240px;">Action</th>
                                            <th>Sl No.</th>
                                                <th>Name</th>
                                                <th>Description</th>
                                                <th>Short Description</th>
                                                <th>Author</th>
                                                <th>Date</th>
                                                <th>File</th>
                                                 
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                                $sqlfetch = "SELECT * FROM blogs";

                                                $sqlfetch = mysqli_query($conn,$sqlfetch);

                                                $i = 1;

                                                while ($row = mysqli_fetch_array($sqlfetch))

                                                {
                                                    
                                               
                                                    $id=$row['id'];

                                            ?>
                                            <tr>
                                                <td class="text-center" style="color:#000;">
                                                        
                                                        
                                            <a href="blog_add.php?id=<?php echo $row['id']; ?>"><i class="fas fa-edit" style="color:#000;"></i></a> |
                                            <a href="?delid=<?php print $row['id']; ?>" onclick ="return confirm('Are you sure to delete ?')"><i class="fas fa-trash-alt" style="color:#000;"></i></a></td>
                                                        
                                                    </td> 
                                           
                                                 <td style="color:#000;"><?php echo $i; ?></td>
                                                <td style="color:#000;"><?php echo $row['blog_title']; ?></td>
                                                <td style="color:#000;"><?php echo $row['short_description']; ?></td>
                                                <td style="color:#000;"><?php echo $row['description']; ?></td>
                                                <td style="color:#000;"><?php echo $row['author']; ?></td>
                                                <td style="color:#000;"><?php echo date('d/m/Y',strtotime($row['date'])); ?></td>
                                                <td style="color:#000;"><img src="upload/<?php echo $row["file"];?>" style="max-width: 150px"></td>
                                            </tr>
                                        <?php 

                                            $i++;

                                            } ?>                                             
                                    
                                            
                                           
                                          
                                            
                                        </tbody>
                                        
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    <?php include "include/footer.php";?>