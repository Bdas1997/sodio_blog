<?php
error_reporting(0);
include 'connection.php';
if(isset($_POST['submit'])){
$password = md5($_POST["password"]); 
 $sql = "Select * from registration where password='$password'";
 $result = mysqli_query($conn,$sql);

    $num = mysqli_num_rows($result);
    if ($num > 0){
        while($row=mysqli_fetch_assoc($result)){
            
                session_start();
                
                $_SESSION['password'] = md5($password);
                
                header("location:dashboard.php");
            }
           
        }
        else{
          $msg = "Incorrent Password";
            setcookie("msg", $msg, time() + 3);
            print "<script>";
            print "self.location = 'page-lock-screen.php';";
            print "</script>";
            exit;
        }
        
    
   
}
    

?>

<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Admin</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/logo.jpeg">
    <link href="./css/style.css" rel="stylesheet">

</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container-fluid h-100">
            <div class="row justify-content-center h-100 align-items-center">

                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <!--message-->
      <?php if ($_COOKIE['msg']) { ?>
        <div class="clearfix"></div>
        <div class="col-lg-8">        
        <div class="alert alert-success">
          <a href="#" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
          <?php print str_replace("+", " ", $_COOKIE['msg']); ?>
        </div>
        </div>
      <?php } ?>
      <!--message--> 
                                <div class="auth-form">
                                    <h4 class="text-center mb-4">Account Locked</h4>
                                    <form action="" method="POST">
                                        <div class="form-group">
                                            <label><strong>Password</strong></label>
                                            <input type="password" class="form-control" name="password">
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" name="submit" class="btn btn-primary btn-block">Unlock</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- #/ container-fluid -->
    <!-- Common JS -->
    <script src="./vendor/global/global.min.js"></script>
    <!-- Custom script -->
    <script src="./vendor/quixnav/quixnav.min.js"></script>
    <script src="./js/quixnav-init.js"></script>
    <script src="./js/custom.min.js"></script>
</body>

</html>