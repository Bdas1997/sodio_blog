<?php
session_start();
error_reporting(1);
include('connection.php');
if (!isset($_SESSION['username'])):
    header("location:index.php");
endif;

include("include/header.php");
include("include/nav.php");


$stage 	= $_POST['stage'];

if ($stage == 2) {

    $username = $_POST['username'];
    $oldpwd_md5 = md5($oldpwd);
    $newpwd_md5 = md5($newpwd);

    $mysql = "select password from registration where username='" . $username . "' AND type = 1";
    $query = mysqli_query($conn,$mysql);
    $row = mysqli_fetch_row($query);

    if (trim($row[0]) != $oldpwd) {

        $msg = "Invalid Old Password, Please Try Again.";
		setcookie("msg", $msg, time() + 3);
        print "<script>";
        print "self.location ='cpass.php';";
        print "</script>";
    } else {

        $strsql1 = "update registration set password='" . $newpwd . "' where username = '" . $eusername . "' AND type = 1";
        // print_r($strsql1);
        // die();
        $result2 = mysqli_query($conn,$strsql1);

        $msg = "Password changed successfully.";
		setcookie("msg", $msg, time() + 3);
        print "<script>";
        print "self.location = 'cpass.php';";
        print "</script>";
    }
	}


?>

<script type="text/javascript">
	function validate(){
		if (document.pwd.oldpwd.value == "") {
			alert("Enter Your Old Password.");
			document.pwd.oldpwd.focus();
			return false;
		}
		if (document.pwd.newpwd.value == "") {
			alert("Enter Your New Password.");
			document.pwd.newpwd.focus();
			return false;
		}
		if (document.pwd.cnewpwd.value == "") {
			alert("Retype Your New Password.");
			document.pwd.cnewpwd.focus();
			return false;

		}
		if (document.pwd.newpwd.value != "" && document.pwd.cnewpwd.value != "")
		{
			if (document.pwd.newpwd.value != document.pwd.cnewpwd.value)
			{
				alert("New Password Mismatched.");
				document.pwd.cnewpwd.focus(); 
				return false;
			}
		}
	}
</script>
</head>
<div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-12 p-md-0 ">
                        <div class="welcome-text">
                            <h4>Change Password</h4>
                            
                        </div>
                            <p class="m-b-0 text-muted">
                                 
                            </p>
                        </div>
                    <form name="pwd" method="POST" action="cpass.php" onSubmit="return validate();" >
   <input type="hidden" name="stage" value="2">
        <div class="col-sm-12 p-md-0 ">
                        
                        <div class="card-body ">                   
                        
                            <div class="form-row m-b-20 ">
                            <label for="heading" >User Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php print $_SESSION['name']; ?>" readonly >
                            </div>
                            <div class="form-row m-b-20">
                            <label for="heading" >Old Password</label>
                            <input type="password" class="form-control" id="oldpwd" name="oldpwd" value="" required >
                            </div>
                            <div class="form-row m-b-20">
                            <label for="heading" >New Password</label>
                            <input type="password" class="form-control" id="newpwd" name="newpwd" value="" required>
                            </div>
                            <div class="form-row m-b-20">
                            <label for="heading" >Confirm Password</label>
                            <input type="password" class="form-control" id="conpwd" name="cnewpwd" value="" required>
                            </div>
                           
                            
                            <div class="form-group mt-2">
                                <button type="submit"  class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                    
                        </form>

                    </div>
                </div>
            </div>
<?php include("include/footer.php"); ?>