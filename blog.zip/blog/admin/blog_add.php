<?php
session_start();
include 'connection.php';
error_reporting(0);
if (!isset($_SESSION['username'])){
    header("location:index.php");
}
include "include/header.php";

include "include/nav.php";

$blog_title=mysqli_real_escape_string($conn,$_POST['blog_title']);
$short_description=mysqli_real_escape_string($conn,$_POST['short_description']);
$description=mysqli_real_escape_string($conn,$_POST['description']);

$author=$_POST['author'];
$date=$_POST['date'];

$allowed_extensions = array('gif', 'jpg','jpeg', 'png','bmp', 'GIF', 'JPG', 'PNG', 'JPEG','BMP');
$stage = $_POST['stage'];

if ($stage == 2) {

    if ($_FILES['pimg']['name'] != "") {

        $filenamenew = $_FILES['pimg']['name'];

        $path_info = pathinfo($filenamenew);

        $is_valid = in_array($path_info['extension'], $allowed_extensions);

        if (empty($is_valid)) {
            $msg = "Incorrent file extension, Please upload a valid image file";
            setcookie("msg", $msg, time() + 3);
            print "<script>";
            print "self.location = 'blog_add.php';";
            print "</script>";
            exit;
        } else {

            $path2 = "upload";
             $s1 = rand();
            $realname = $_FILES['pimg']['name'];
            $realname = $s1 . "_" . $realname;
            $dest = $path2 . "/" . $realname;
            copy($_FILES['pimg']['tmp_name'], $dest);
            $image = trim($realname);
            $path3 = "upload";
            $delpath1 = $path3 . "/" . $_POST['T2'];
            @unlink($delpath1);

        }

    } else {
        
        $image =$_POST['T2'];

    }

// print_r($stage);
// die();
   $sql="INSERT INTO `blogs`( `blog_title`,`description`,`short_description`,`author`,`file`,`date`,`created_at`) 
  VALUES ('$blog_title','$description','$short_description','$author','$image','$date',date('Y-m-d H:i:s'))";
// print_r($sql);
// die();
       $result3 = mysqli_query($conn,$sql);
      
    $msg = "Blog Added Successfully.";
    setcookie("msg", $msg, time() + 3);
    print "<script>";
    print "self.location = 'blog_view.php';";
    print "</script>";
    exit;
}
/* EDIT Template */

if ($_POST['stage'] == 3 && $_POST['rid'] != "") {
    
    if ($_FILES['pimg']['name'] != "") {
        $filenamenew = $_FILES['pimg']['name'];
        $path_info = pathinfo($filenamenew);
        $is_valid = in_array($path_info['extension'], $allowed_extensions);
        if (empty($is_valid)) {
          $msg = "Incorrent file extension, Please upload a valid image file";
            setcookie("msg", $msg, time() + 3);
            print "<script>";
            print "self.location = 'blog_view.php';";
            print "</script>";
            exit;
        } else {

    $path2 = "upload";
            $s1 = rand();
            $realname = $_FILES['pimg']['name'];
            $realname = $s1 . "_" . $realname;
            $dest = $path2 . "/" . $realname;
            copy($_FILES['pimg']['tmp_name'], $dest);
            $image = trim($realname);
            $path3 = "upload";
            $delpath1 = $path3 . "/" . $_POST['T2'];
            @unlink($delpath1);
        }



    } else {



        $image =$_POST['T2'];

    }
   

    $sql="UPDATE `blogs` SET `blog_title`='$blog_title',`short_description`='$short_description',`author`='$author',`file`='$image,`description`='$description',`status`='$status',`updated_at` = date('Y-m-d H:i:s') WHERE id=" . $_POST['rid'] . "";
// print_r($sql);
// die();
  $result3 = mysqli_query($conn,$sql);
  //include('pagemanipulate.php');
    $msg = "blog Updated Successfully.";
    setcookie("msg", $msg, time() + 3);
    print "<script>";
    print "self.location = 'blog_view.php';";
    print "</script>";
    exit;
}

if ($_GET['id'] != "") {
    $sql = "select * from blog where id=" . $_GET['id'] . "";
    
    $row = mysqli_fetch_assoc(mysqli_query($conn,$sql));
  
  $eid = $row['id'];
}

$page="blog";


?>


</head>
 <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                     
                    <div class="col-sm-12 p-md-0">
                        <div class="welcome-text">
                            <h4>Blog Master</h4>
                            
                        </div>

                    <form name="pwd" method="POST" id="Addproduct" action="blog_add.php" enctype="multipart/form-data" >
                        <!--message-->
      <?php if ($_COOKIE['msg']) { ?>
        <div class="clearfix"></div>
        <div class="col-lg-8">        
        <div class="alert alert-success">
          <a href="#" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
          <?php print str_replace("+", " ", $_COOKIE['msg']); ?>
        </div>
        </div>
      <?php } ?>
      <!--message-->
    
         <?php if ($eid == "") { ?>
    <input type="hidden" name="stage" value="2">
    <?php } else { ?>
    <input type="hidden" name="stage" value="3">
    <input type="hidden" name="rid" value="<?php print $eid; ?>">
    <?php } ?>
                        
                        <div class="card-body">                   
                           
                            <div class="form-row m-b-20">
                            <label for="heading" style="color:#000;">Blog Title <span style="color:#ff0000;">*</span></label>
                            <input type="text" class="form-control" id="title" name="blog_title" value="<?php print $row['blog_title'];?>" style="color:#000" required>
                            </div>
                            <div class="form-row m-b-20">
                            <label for="buyers" style="color:#000;" >Blog Short Description <span style="color:#ff0000;">*</span></label>
                            <textarea class="form-control" id="short_desc" name="short_description"  style="color:#000" required ><?php print $row['short_description'];?></textarea>
                            </div>
                            <div class="form-row m-b-20">
                            <label for="buyers" style="color:#000;" >Blog Description <span style="color:#ff0000;">*</span></label>
                            <textarea class="form-control" id="description" name="description"  style="color:#000" required ><?php print $row['description'];?></textarea>
                            </div>
                            
          
                            <div class="form-row m-b-20">
                            <label for="heading" style="color:#000;" >Author <span style="color:#ff0000;">*</span></label>
                            <input type="text" class="form-control" id="author" name="author" value="<?php print $row['author'];?>"  style="color:#000"  >
                            </div>

                            <div class="form-row m-b-20">
                            <label for="heading" style="color:#000;" >Date <span style="color:#ff0000;">*</span></label>
                            <input type="date" class="form-control" id="date" name="date" value="<?php print $row['date'];?>"  style="color:#000"  >
                            </div>
                           
                           
                            <div class="form-row form-group">
                            <label for="category" style="color:#000;">Blog Image <span style="color:#ff0000;">*</span></label>
                            <input type="file" class="form-control" id="image" name="pimg" placeholder="">
                             
                            </div>
                            <?php if ($row['file'] != "") { ?>

                            <div class="clearfix"></div>

                            <div class="form-row">

                            <img src="upload/<?php print $row['file']; ?>" style="width: 200px;height:200px; " class="img-responsive" />  

                            </div>

                            <?php } ?>

                            <input type="hidden" name="T2" value="<?php print $row['file']; ?>">
                            <div class="form-row form-group">
                            
                              
                            <div class="form-group">
                                <input type="submit"  class="btn btn-primary" value="submit">
                            </div>

                        </div>
                    </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

           
      
<?php
include "include/footer.php";
?>