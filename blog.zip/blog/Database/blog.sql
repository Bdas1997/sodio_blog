-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2024 at 10:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `blog_title` varchar(255) DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1 COMMENT '1.Active 2.Inactive',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `blog_title`, `short_description`, `description`, `author`, `file`, `date`, `status`, `created_at`, `updated_at`) VALUES
(1, '1st Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(2, '2nd Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(3, '3rd Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(4, '4th Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(5, '5th Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(6, '6th Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(7, '7th Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(8, '8th Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(9, '9th Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(10, '10th Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL),
(11, '11th Blog', 'short description', 'descriptuion', 'Author', '1431471970_167529995353672312.jpg', '2024-12-06', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `id` int(11) NOT NULL,
  `blog_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 2 COMMENT '1.Active 2.Inactive',
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `blog_comments`
--

INSERT INTO `blog_comments` (`id`, `blog_id`, `name`, `comment`, `email`, `status`, `created_at`) VALUES
(1, 1, 'Bikash', 'comennt', 'bikash@gmail.com', 1, '2024-12-06 21:59:40'),
(3, 1, 'Bikash ', 'Best Blog', '', 2, '2024-12-07 20:41:49');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL COMMENT '1.Admin 2.User',
  `status` tinyint(4) DEFAULT 1 COMMENT '1.Active 2.Inactive',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `email`, `username`, `password`, `type`, `status`, `created_at`, `updated_at`) VALUES
(1, 'bikashdasok@gmail.com', 'bikash', '672d30ab508237ac28b92c3472c56688', 1, 1, '2024-12-06 21:40:08', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `blog_comments`
--
ALTER TABLE `blog_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
