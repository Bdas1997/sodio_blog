<?php
session_start();
include 'connection.php';
error_reporting(0);

$blog_id=$_POST['blog_id'];
$name=mysqli_real_escape_string($conn,$_POST['name']);
$comment=mysqli_real_escape_string($conn,$_POST['comment']);
$email = $_POST['email'];

$created_at = date('Y-m-d H:i:s'); 
$sql = "INSERT INTO `blog_comments` (`blog_id`, `name`, `email`, `comment`, `status`, `created_at`) 
VALUES ('$blog_id', '$name', '$email', '$comment', '2', '$created_at')";

// print_r($sql);
// die();
     $result3 = mysqli_query($conn,$sql);
    
  $msg = "Comment Added Successfully.";
  setcookie("msg", $msg, time() + 3);
  print "<script>";
  print "self.location = 'blog-details.php?id=$blog_id';";
  print "</script>";
  exit;



?>