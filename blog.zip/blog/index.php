<?php
error_reporting(E_ALL); // Enable error reporting for debugging
ini_set('display_errors', 1);

session_start();
include 'connection.php';

$postsPerPage = 9;

$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$current_page = max($current_page, 1); 

$offset = ($current_page - 1) * $postsPerPage;

$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

if (!empty($search)) {
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM blogs WHERE blog_title LIKE '%$search%' OR author LIKE '%$search%'");
} else {
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM blogs");
}
$totalRows = mysqli_fetch_assoc($result)['total'];
$totalPages = ceil($totalRows / $postsPerPage);

if (!empty($search)) {
    $query = "SELECT * FROM blogs WHERE blog_title LIKE '%$search%' OR author LIKE '%$search%' LIMIT $postsPerPage OFFSET $offset";
} else {
    $query = "SELECT * FROM blogs LIMIT $postsPerPage OFFSET $offset";
}
$blogs = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<?php
include 'includes/header.php';

?>

<body class="blog-page">

<?php
  include 'includes/nav.php';
  ?>

  <main class="main">
    <!-- Page Title -->
    <div class="page-title dark-background" style="background-image: url(assets/img/page-title-bg.webp);">
      <div class="container position-relative">
        <h1>Blog</h1>
        <p>Discover insights and stories from our blog posts.</p>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Blog</li>
          </ol>
        </nav>
      </div>
    </div>
    <!-- End Page Title -->

    <!-- Blog Posts Section -->
    <section id="blog-posts" class="blog-posts section">
      <div class="container">

        <!-- Search Bar -->
        <form method="GET" class="search-form mb-4">
          <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by blog title or author" value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
          </div>
        </form>
        <!-- End Search Bar -->

        <div class="row gy-4">
          <?php while ($row = mysqli_fetch_assoc($blogs)): ?>
            <div class="col-lg-4">
              <article>
                <div class="post-img">
                  <img src="admin/upload/<?php echo $row["file"]; ?>" alt="" class="img-fluid">
                </div>
                <p class="post-category">Category</p>
                <h2 class="title">
                  <a href="blog-details.php?id=<?php echo $row['id']; ?>">
                    <?php echo $row['blog_title']; ?>
                  </a>
                </h2>
                <div class="d-flex align-items-center">
                  <img src="admin/upload/<?php echo $row["file"]; ?>" alt="" class="img-fluid post-author-img flex-shrink-0">
                  <div class="post-meta">
                    <p class="post-author"><?php echo $row['author']; ?></p>
                    <p class="post-date">
                      <time datetime="<?php echo date('Y-m-d', strtotime($row['date'])); ?>">
                        <?php echo date('d/m/Y', strtotime($row['date'])); ?>
                      </time>
                    </p>
                  </div>
                </div>
              </article>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    </section>
    <!-- End Blog Posts Section -->

    <!-- Pagination Section -->
    <section id="blog-pagination" class="blog-pagination section">
      <div class="container">
        <div class="d-flex justify-content-center">
          <ul>
            <!-- Previous Page -->
            <?php if ($current_page > 1): ?>
              <li><a href="?page=<?php echo $current_page - 1; ?>&search=<?php echo urlencode($search); ?>"><i class="bi bi-chevron-left"></i></a></li>
            <?php else: ?>
              <li class="disabled"><a href="#"><i class="bi bi-chevron-left"></i></a></li>
            <?php endif; ?>

            <!-- Page Numbers -->
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
              <li>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" class="<?php echo $i == $current_page ? 'active' : ''; ?>">
                  <?php echo $i; ?>
                </a>
              </li>
            <?php endfor; ?>

            <!-- Next Page -->
            <?php if ($current_page < $totalPages): ?>
              <li><a href="?page=<?php echo $current_page + 1; ?>&search=<?php echo urlencode($search); ?>"><i class="bi bi-chevron-right"></i></a></li>
            <?php else: ?>
              <li class="disabled"><a href="#"><i class="bi bi-chevron-right"></i></a></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </section>
    <!-- End Pagination Section -->

  </main>

  <!-- Footer -->
  <footer id="footer" class="footer dark-background">
    <div class="container">
      <p>© <strong>Bikash</strong> All Rights Reserved</p>
    </div>
  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
              